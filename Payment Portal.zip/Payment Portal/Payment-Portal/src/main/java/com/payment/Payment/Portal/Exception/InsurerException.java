package com.payment.Payment.Portal.Exception;

public class InsurerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsurerException(String message) {
		super(message);
	
	}
	
	

}
