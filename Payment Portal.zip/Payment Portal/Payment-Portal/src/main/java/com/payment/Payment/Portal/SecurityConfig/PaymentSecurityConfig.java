package com.payment.Payment.Portal.SecurityConfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableGlobalMethodSecurity(jsr250Enabled = true)
public class PaymentSecurityConfig extends WebSecurityConfigurerAdapter{
	

	 @Override
	    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	        auth.inMemoryAuthentication().withUser("admin").password("admin").roles("Admin");
	        auth.inMemoryAuthentication().withUser("agent").password("agent").roles("Agent");
	    }

	
	 @Override
	    protected void configure(HttpSecurity http) throws Exception {
	        http        	
	            .authorizeRequests()
	             
	            	.antMatchers("/createAgent", "/agentupdate/{id}","/agentdelete/{id}","/agents/{branch}","/insurers","/insurerupdate/{id}","/insurerdelete/{id}").hasRole("Admin")
	                .antMatchers("/createInsurer","/insurers","/insurer/{id}","/insurerupdate/{id}").hasRole("Agent")
	                .anyRequest().authenticated()
	                ;
	    }
	    

}
