package com.payment.Payment.Portal.Controller;


import java.util.List;


import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.payment.Payment.Portal.Agent.Agent;
import com.payment.Payment.Portal.Exception.AgentException;
import com.payment.Payment.Portal.Exception.InsurerException;
import com.payment.Payment.Portal.Insurer.Insurer;
import com.payment.Payment.Portal.Service.PaymentService;


@RestController
public class PaymentController {

	@Autowired
	PaymentService paymentService;
	
	 @RolesAllowed(value = { "Admin" })
	 @PostMapping("/createAgent")
	 public void createAgent(@RequestBody Agent agent) throws AgentException {
		 paymentService.createAgent(agent);
	 }
	 
	 @RolesAllowed(value = { "Admin" })
	 @PutMapping("/agentupdate/{id}")
	 public ResponseEntity<Agent> updateAgent(@PathVariable int id, @RequestBody Agent agent) throws AgentException{
		 
		 agent.setId(id);
		 return ResponseEntity.ok().body(this.paymentService.updateAgent(agent));
	 }
	 
	 @RolesAllowed(value = { "Admin" })
	 @DeleteMapping("/agentdelete/{id}")
	 public void deleteAgent(@PathVariable int id) throws AgentException {
		 paymentService.deleteAgent(id);
	 }
	 
	 @RolesAllowed(value = { "Admin" })
	 @GetMapping("/agents/{branch}")
	 public List<Agent> findAgentByBranch(@PathVariable("branch") String branch) throws AgentException {
	     return paymentService.findAgentByBranch(branch);
	 }
	 
	 @RolesAllowed(value = { "Agent" })
	 @PostMapping("/createInsurer")
	 public void createInsurer(@RequestBody Insurer insurer) throws InsurerException {
		 paymentService.createInsurer(insurer);
	 }
	 
	 @RolesAllowed(value = { "Admin" , "Agent"})
	 @GetMapping("/insurers")
	 public List<Insurer> searchAllInsurers() throws InsurerException {
	     return paymentService.getAllInsurers();
	 }
	 
	 @RolesAllowed(value = { "Admin" , "Agent"})
	 @GetMapping("/insurer/{id}") 
	 private Insurer getInsurerById(@PathVariable("id") int id) throws InsurerException   
	 {  
	 return paymentService.getInsurerById(id); 
	 }  
	 
	 @RolesAllowed(value = { "Admin" , "Agent"})
	 @PutMapping("/insurerupdate/{id}")
	 public ResponseEntity<Insurer> updateInsurer(@PathVariable int id, @RequestBody Insurer insurer) throws InsurerException{
		 
		 insurer.setId(id);
		 return ResponseEntity.ok().body(this.paymentService.updateInsurer(insurer));
	 }
	 
	 @RolesAllowed(value = { "Admin" })
	 @DeleteMapping("/insurerdelete/{id}")
	 public void deleteInsurer(@PathVariable int id) throws InsurerException {
		 paymentService.deleteInsurer(id);
	 }
	 
	
}
