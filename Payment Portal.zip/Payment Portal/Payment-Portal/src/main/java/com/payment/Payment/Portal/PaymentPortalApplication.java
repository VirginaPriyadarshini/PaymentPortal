package com.payment.Payment.Portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.payment.Payment.Portal"})
public class PaymentPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentPortalApplication.class, args);
	}

}
