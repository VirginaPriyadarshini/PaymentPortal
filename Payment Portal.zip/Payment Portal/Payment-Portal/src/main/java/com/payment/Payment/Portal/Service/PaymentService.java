package com.payment.Payment.Portal.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.Payment.Portal.Agent.Agent;
import com.payment.Payment.Portal.Exception.AgentException;
import com.payment.Payment.Portal.Exception.InsurerException;
import com.payment.Payment.Portal.Insurer.Insurer;
import com.payment.Payment.Portal.Repository.AgentRepository;
import com.payment.Payment.Portal.Repository.InsurerRepository;

@Service
@Transactional
public class PaymentService {
	
	@Autowired
	AgentRepository agentRepository;
	@Autowired
	InsurerRepository insurerRepository;
	
	public void createAgent(Agent agent) throws AgentException {
		agentRepository.save(agent);
    }
	
	public Agent updateAgent(Agent agent) throws AgentException {
    	
    	Optional<Agent> agentDb = this.agentRepository.findById(agent.getId());
    	if(agentDb.isPresent()) {
    		
    		Agent agentUpdate = agentDb.get();
    		agentUpdate.setId(agent.getId());
    		agentUpdate.setName(agent.getName());
    		agentUpdate.setPassword(agent.getPassword());
    		agentUpdate.setBranch(agent.getBranch());
    		agentUpdate.setSalary(agent.getSalary());
    		agentRepository.save(agentUpdate);
    		return agentUpdate;
    	}else {
    		throw new AgentException("Agent not found with id:" +agent.getId());
    	}
    }
	
	 public void deleteAgent(int id) throws AgentException {
		 agentRepository.deleteById(id);
	    }
	 
	 public List<Agent> findAgentByBranch(String branch) throws AgentException{
		return agentRepository.findAgentByBranch(branch);
		 
	 }
	 
	 public void createInsurer(Insurer insurer) throws InsurerException {
		 insurerRepository.save(insurer);
	    }
	 
	 public List<Insurer> getAllInsurers() throws InsurerException {
	        return insurerRepository.findAll();
	 }
	 public Insurer getInsurerById(int id) throws InsurerException{
	        return insurerRepository.findById(id).get();
	    }
	     
	 public void deleteInsurer(int id) throws InsurerException {
		 insurerRepository.deleteById(id);
	    }
	 public Insurer updateInsurer(Insurer insurer) throws InsurerException {
	    	
	    	Optional<Insurer> insurerDb = this.insurerRepository.findById(insurer.getId());
	    	if(insurerDb.isPresent()) {
	    		
	    		Insurer insurerUpdate = insurerDb.get();
	    		insurerUpdate.setId(insurer.getId());
	    		insurerUpdate.setName(insurer.getName());
	    		insurerUpdate.setAge(insurer.getAge());
	    		insurerUpdate.setEmailId(insurer.getEmailId());
	    		insurerUpdate.setGender(insurer.getGender());
	    		insurerUpdate.setAddress(insurer.getAddress());
	    		insurerUpdate.setAmountInsured(insurer.getAmountInsured());
	    		insurerUpdate.setMonthyPremium(insurer.getMonthyPremium());
	    		insurerUpdate.setPhoneNumber(insurer.getPhoneNumber());
	    		insurerUpdate.setPaymentStatus(insurer.getPaymentStatus());
	    		insurerUpdate.setPolicyNumber(insurer.getPolicyNumber());
	    		insurerRepository.save(insurerUpdate);
	    		return insurerUpdate;
	    	}else {
	    		throw new InsurerException("Insurer not found with id:" +insurer.getId());
	    	}
	    }
	

}
