package com.payment.Payment.Portal.Exception;

public class AgentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AgentException(String message) {
		super(message);
		
	}

	
}
