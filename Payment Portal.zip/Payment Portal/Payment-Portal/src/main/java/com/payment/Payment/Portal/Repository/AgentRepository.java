package com.payment.Payment.Portal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.payment.Payment.Portal.Agent.Agent;

@Repository
public interface AgentRepository extends JpaRepository<Agent,Integer> {

	List<Agent> findAgentByBranch(String branch);
}
