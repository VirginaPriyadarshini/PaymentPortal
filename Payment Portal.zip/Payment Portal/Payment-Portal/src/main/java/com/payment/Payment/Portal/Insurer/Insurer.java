package com.payment.Payment.Portal.Insurer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Insurer")
public class Insurer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Id")
	private int id;
	@Column(name="Name")
	private String name;
	@Column(name="Address")
	private String address;
	@Column(name="EmailId ")
	private String emailId;
	@Column(name="PhoneNumber")
	private String phoneNumber;
	@Column(name="Age")
	private int age;
	@Column(name="Gender")
	private String gender;
	@Column(name = "AmountInsured")
	private long amountInsured;
	@Column(name= "MonthlyPremium")
	private long monthyPremium;
	@Column(name = "PolicyNumber")
	private long policyNumber;
	@Column(name = "PaymentStatus")
	private String paymentStatus;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getAmountInsured() {
		return amountInsured;
	}
	public void setAmountInsured(long amountInsured) {
		this.amountInsured = amountInsured;
	}
	public long getMonthyPremium() {
		return monthyPremium;
	}
	public void setMonthyPremium(long monthyPremium) {
		this.monthyPremium = monthyPremium;
	}
	public long getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
	
}
